package com.example.student.bricklist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView projectList;
    private Button newProject;
    private ProjectAdapter projectAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        projectList = findViewById(R.id.projectsList);
        newProject = findViewById(R.id.newProject);

        final List<Project> projectsList = new ArrayList<>();
        projectsList.add(new Project(0, "pierwszy projekt"));
        projectsList.add(new Project(0, "drugi projekt"));
        projectAdapter = new ProjectAdapter(this, projectsList);

        projectList.setAdapter(projectAdapter);

        newProject.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                final List<Project> newProjectsList = new ArrayList<>();
                newProjectsList.add(new Project(0, "pierwszy projekt"));
                newProjectsList.add(new Project(0, "drugi projekt"));
                projectAdapter.changeDataSet(newProjectsList);
            }
        });
    }
}
