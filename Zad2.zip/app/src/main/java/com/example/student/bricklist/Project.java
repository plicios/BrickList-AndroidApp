package com.example.student.bricklist;

/**
 * Created by student on 28.05.2018.
 */

public class Project {
    private long id;
    private String name;

    public Project(long id, String name) {
        this.id = id;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
